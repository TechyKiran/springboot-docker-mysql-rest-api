package com.example.DockerwithMultifiles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DockerwithMultifilesApplication {

	public static void main(String[] args) {
		SpringApplication.run(DockerwithMultifilesApplication.class, args);
	}

}
